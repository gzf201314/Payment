﻿
Ext.define('JajaApp.view.ResultView', {
    extend: 'Ext.Container',
    xtype: 'resultview',

    requires: [],

    config: {
        id: 'resultview',
        fullscreen: true,
        layout: 'vbox', //布局
        autoDestroy: true,
        items: [{
            xtype: 'toolbar',
            cls: 'toolbar',
            ui: 'light',
            docked: 'top',
            title: '自助结账',
            style: {
                'background': '#0078d7',
                'border-top': '0px',
                'border-bottom-width': '0px'
            },
            items: [{
                xtype: 'button',
                ui: 'back',
                id: 'ResultBack',
                style: {
                    'background': '#0078d7',
                    'margin-left': '-10px',
                    'color': '#fff'
                },
                text: '返回'
            }, {
                xtype: 'spacer'//空格
            }]
        }, {
            xtype: 'formpanel',
            width: '100%',
            height: '100%',
            cls: 'code-form',
            scrollable: {
                direction: 'vertical',
                indicators: false
            },
            style: {
                'background-color': '#ffffff'
            },
            items: [{
                xtype: 'fieldset',
                margin: 0,
                width: '100%',
                style: {
                    '-webkit-border-radius': '0',
                    'border-radius': '0'
                },
                defaults: {
                    labelWidth: '37%',
                    labelCls: 'reg-lable',
                    inputCls: 'inputstyle'
                },
                items: [{
                    xtype: 'textareafield',
                    name: 'name',
                    id: "txtMerchants",
                    readOnly: true,
                    maxRows: 2,
                    label: '商家名称：',
                    placeHolder: '请输入商家名称'
                }, {
                    xtype: 'numberfield',
                    name: 'name',
                    readOnly:true,
                    id: "txtAmount",
                    label: '结账金额：',
                    placeHolder: '请输入结账金额',
                    value: 1
                }]
            }, {
                xtype: 'button',
                id: 'CompleteButton',
                width: '95%',
                style: {
                    'font-size': '1.3em',
                    'font-weight': '500',
                    'color': '#157efb',
                    'border-radius': '6px',
                    'border': '1px solid #157efb',
                    'background-color': '#fff',
                    'background-image': 'none',
                    'margin-top': '120px',
                    'margin-left': 'auto',
                    'margin-right': 'auto'
                },
                text: '完&nbsp;&nbsp;&nbsp;成'
            }]
        }]
    }
});