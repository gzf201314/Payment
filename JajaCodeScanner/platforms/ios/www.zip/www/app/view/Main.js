﻿//主视图文件
Ext.define('JajaApp.view.Main', {
    extend: 'Ext.Container',
    xtype: 'mainview',

    requires: [
       'Ext.XTemplate'
       ],

    config: {
        id: 'mainview',
        fullscreen: true,
        layout: 'fit', //布局
        width: '100%',
        height: '100%',
        autoDestroy: true,
        items: [{
            xtype: 'toolbar',
            cls: 'toolbar',
            ui: 'light',
            docked: 'top',
            title: '扫码支付',
            height: 44,
            style: {
                'background': '#0078d7',
                'border-top': '0px',
                'border-bottom-width': '0px'
            }, items: [{
                xtype: 'spacer'
            }]
        }, {
            xtype: 'container',
            id: 'tabContainer',
            autoDestroy: true,
            flex: 1,
            items: [{
                xtype: 'button',
                centered: true,
                id: 'QRCodeButton',
                style: {
                    'width': '95%',
                    'font-size': '1.3em',
                    'font-weight': '500',
                    'color': '#157efb',
                    'border-radius': '6px',
                    'border': '1px solid #157efb',
                    'background-color': '#fff',
                    'background-image': 'none',
                    'margin-top': '20px',
                    'margin-left': 'auto',
                    'margin-right': 'auto'
                },
                text: '扫一扫'
            }]
        }, ]
    }
});