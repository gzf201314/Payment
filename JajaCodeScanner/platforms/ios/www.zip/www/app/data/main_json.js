﻿[{
    "RegMenuID": "reg001",
    "Message": "软件注册",
    "Remark": "生成软件注册码",
    "badgeText": "none",
    "Count":"0"
}, {
    "RegMenuID": "reg002",
    "Message": "临时注册记录",
    "Remark": "可以查看正在试用的客户记录",
    "badgeText": "none",
    "Count": "0"
},
//{
//    "RegMenuID": "reg003",
//    "Message": "正式码记录",
//    "Remark": "可以查看拥有正式码的客户记录"
//},
 {
 "RegMenuID": "reg003",
 "Message": "待处理列表",
 "Remark": "可以查看申请正式码的客户记录",
 "badgeText": "block",
 "Count": "0"
},
 {
     "RegMenuID": "reg004",
     "Message": "正式注册记录",
     "Remark": "可以查看拥有正式码的客户记录",
     "badgeText": "none",
     "Count": "0"
 }
// ,
// {
//     "RegMenuID": "reg005",
//     "Message": "授权用户",
//     "Remark": "可以查看拥有登录权限的代理商",
//     "badgeText": "none",
//     "Count": "0"
// }
 ]