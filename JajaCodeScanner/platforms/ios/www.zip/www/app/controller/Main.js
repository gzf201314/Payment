﻿// 路由
var Route = {
    Main: 'main',
    Login: 'login',
    Result: 'result',
    Record: 'record',
    Ask: 'ask',
    Official: 'official'
};

//主控制器脚本文件
Ext.define('JajaApp.controller.Main', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            mainview: {
                selector: 'mainview',
                xtype: 'mainview',
                id: 'mainview',
                autoCreate: true
            },
            QRCodeButton: '#QRCodeButton'
        },
        control: {
            mainview: {
                activate: 'onInit'
            },
            QRCodeButton: {
                tap: 'showQRCodeView'
            }
        },
        routes: {
            'main': 'showMainView'
        }
    },
    /**
    * 页面激活 ------ 每次显示当前页面，都会执行这段代码
    */
    onInit: function (newActiveItem, sender, oldActiveItem, eOpts) {
        var me = this;
        if (oldActiveItem != 0 && oldActiveItem.getId() == 'resultview') {
            Progress.animate(this.getMainview(), 'left');
        }
    },
    // 调用原生接口
    showQRCodeView: function () {
        var me = this;
        cordova.plugins.barcodeScanner.scan(function (result) {
//             alert("We got a barcode\n" +
//               "Result: " + result.text + "\n" +
//               "Format: " + result.format + "\n" +
//               "Cancelled: " + result.cancelled);
            
            if(result.cancelled =='0')
            {
                Common.redirectTo(me, Route.Main, Route.Result); // 数据加载完成进行跳转。
                // 1.检测通过之后
                var merchants = result.text, // 商家名称
                    amount = "1000.00"; // 结账金额
                
                // 2.给核对页面进行赋值
                Common.setValue('txtMerchants', merchants);
                Common.setValue('txtAmount', amount);
            }
           
        }, function (error) {
            alert("Scanning failed: " + error);
        });

    },
    showMainView: function () {
        Progress.animate(this.getMainview(), 'right');
        Ext.Viewport.setActiveItem(this.getMainview());
    }
});