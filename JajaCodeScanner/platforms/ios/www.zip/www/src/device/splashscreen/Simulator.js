/**
 * @private
 */
Ext.define('Ext.device.splashscreen.Simulator', {
    extend: 'Ext.device.splashscreen.Abstract'
});
