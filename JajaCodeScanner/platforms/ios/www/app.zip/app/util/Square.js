﻿Ext.define("util.Square", {
    alternateClassName: "square",
    singleton: true,
    config: {
        description: '加加餐饮软件'
    },
    constructor: function (config) {
        this.initConfig(config);
    },
    show: function () {

    }
});