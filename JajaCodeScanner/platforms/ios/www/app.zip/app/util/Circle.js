﻿Ext.define("util.Circle", {
    alternateClassName: "circle",
    singleton: true,
    config: {
        description: '加加餐饮软件'
    },

    constructor: function (config) {
        this.initConfig(config);
    },
    show: function () {

    }
});