﻿[{
    "MenuID": "001",
    "Route": "setting",
    "Message": "账号设置"
}, {
    "MenuID": "002",
    "Route": "about",
    "Message": "关于软件"
}, {
    "MenuID": "004",
    "Route": "lianxi",
    "Message": "联系我们"
}]