﻿[{
    "BillID": "1000001",
    "BillTime": "2015-11-06",
    "BillJinE": "230",
    "State":"交易成功"
}]